import json
import os
import requests
import pandas as pd  # 新增导入pandas
from .SM4Utils import SM4Crypto
from typing import Any, Dict, Optional, Union, List
from .exceptions import CryptoError, HttpStatusError, ResponseDecodeError
from .case_converter import snake_to_camel, camel_to_snake, transform_keys


class DMQuantApiClient:
    """
    对外：
        client = DMQuantApiClient(app_key=..., app_secret=..., base_url=可选)
        client.post_data(data, return_type="dict")  # 返回字典
        client.post_data(data, return_type="dataframe")  # 返回DataFrame

    认证参数：
        app_key: 应用标识
        app_secret: 应用密钥（也可使用 sm4_key，二者等价）

    内部：
        - 加密传输
        - headers / path / requests session 都隐藏
    """

    _DEFAULT_BASE_URL = "https://gapi-ext.innodealing.com"
    _REQUEST_CASE_STYLES = {"raw", "auto", "snake", "camel"}
    _RESPONSE_CASE_STYLES = {"raw", "auto", "snake", "camel"}

    def __init__(
            self,
            *,
            app_key: Optional[str] = None,
            app_secret: Optional[str] = None,
            sm4_key: Optional[str] = None,
            base_url: Optional[str] = None,
            timeout: Union[int, float] = 10,
            verify_ssl: bool = True,
            session: Optional[requests.Session] = None,
            user_agent: Optional[str] = None,
            default_headers: Optional[Dict[str, str]] = None,
            request_case_style: str = "raw",
            response_case_style: str = "raw",
            pythonic: bool = False,
    ):
        # 兜底：允许从环境变量拿，方便部署
        app_key = app_key or os.getenv("INNO_APP_KEY")
        # app_secret 与 sm4_key 等价，优先使用 app_secret
        secret = (
            app_secret
            or sm4_key
            or os.getenv("INNO_APP_SECRET")
            or os.getenv("INNO_SM4_KEY")
        )

        if not app_key:
            raise ValueError("app_key is required (or set env INNO_APP_KEY)")
        if not secret:
            raise ValueError("app_secret is required (or set env INNO_APP_SECRET)")

        self.base_url = (base_url or self._DEFAULT_BASE_URL).rstrip("/")
        self.timeout = timeout
        self.verify_ssl = verify_ssl
        self.session = session or requests.Session()
        self.crypto = SM4Crypto(secret)
        self.request_case_style = self._normalize_case_style(
            request_case_style, self._REQUEST_CASE_STYLES, "request_case_style"
        )
        self.response_case_style = self._normalize_case_style(
            response_case_style, self._RESPONSE_CASE_STYLES, "response_case_style"
        )

        if pythonic:
            self.request_case_style = "auto"
            self.response_case_style = "snake"

        self._headers = {
            "User-Agent": user_agent
                          or "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36",
            "Content-Type": "application/json",
            "X-Dm-App-Key": app_key,
        }
        if default_headers:
            self._headers.update(default_headers)

    # ================== 对外接口（支持两种返回类型） ==================
    def post_data(self, data: Dict[str, Any], api_path: str, return_type: str = "dataframe") -> Union[Dict[str, Any], pd.DataFrame]:
        """
        发送加密请求，支持返回字典或DataFrame
        :param data: 请求参数字典
        :param api_path: API路径，如 "/bond-price/api/v1/bond/price/calculate"
        :param return_type: 可选 "dict"（原始字典）/ "dataframe"（默认，DataFrame）
        :return: 字典 | pandas DataFrame
        """
        raw_data = self._post(api_path, data)
        
        # 返回原始字典（方便提取records）
        if return_type == "dict":
            return raw_data
        # 返回DataFrame（兼容原有逻辑）
        return self._convert_to_dataframe(raw_data)

    # ================== 内部方法（无需修改） ==================
    def _post(self, path: str, data: Dict[str, Any]) -> Any:
        url = self.base_url + path
        payload = self._encrypt(self._transform_request_data(data))

        rsp = self.session.post(
            url,
            headers=self._headers,
            data=payload,
            timeout=self.timeout,
            verify=self.verify_ssl,
        )

        if rsp.status_code != 200:
            raise HttpStatusError(rsp.status_code, rsp.text)

        try:
            content = rsp.json()
        except Exception as e:
            raise ResponseDecodeError(
                f"response is not json: {e}, body={rsp.text[:500]}"
            ) from e

        result = self._decrypt(content)

        # 提取 data 字段
        if isinstance(result, dict):
            if result.get("code") != 0:
                raise ResponseDecodeError(f"API error: {result.get('message', 'unknown error')}")
            return self._transform_response_data(result.get("data", result))
        return self._transform_response_data(result)

    def _encrypt(self, data: Dict[str, Any]) -> str:
        try:
            plaintext = json.dumps(data, ensure_ascii=False, separators=(",", ":"))
            return self.crypto.encrypt(plaintext)
        except Exception as e:
            raise CryptoError(f"encrypt failed: {e}") from e

    def _decrypt(self, content: Any) -> Any:
        try:
            decrypted = self.crypto.decrypt(content)
        except Exception as e:
            raise CryptoError(f"decrypt failed: {e}") from e

        if isinstance(decrypted, (dict, list)):
            return decrypted

        if isinstance(decrypted, (bytes, bytearray)):
            decrypted = decrypted.decode("utf-8", errors="replace")

        if isinstance(decrypted, str):
            s = decrypted.strip()
            if (s.startswith("{") and s.endswith("}")) or (s.startswith("[") and s.endswith("]")):
                try:
                    return json.loads(s)
                except Exception:
                    pass
        return decrypted

    def _convert_to_dataframe(self, raw_data: Any) -> pd.DataFrame:
        """
        将解密后的原始数据转换为DataFrame
        适配常见数据格式：列表套字典、字典套列表、纯列表、纯字典
        """
        # 情况1：原始数据是列表（最常见，如 [{"col1":v1}, {"col2":v2}]）
        if isinstance(raw_data, List):
            try:
                return pd.DataFrame(raw_data)
            except Exception as e:
                raise ValueError(f"无法将列表数据转换为DataFrame: {e}") from e
        
        # 情况2：原始数据是字典，且值为列表（如 {"data": [v1, v2], "columns": [c1, c2]}）
        elif isinstance(raw_data, Dict):
            # 优先检查是否有标准的data/columns结构
            if "data" in raw_data and "columns" in raw_data:
                try:
                    return pd.DataFrame(raw_data["data"], columns=raw_data["columns"])
                except Exception as e:
                    raise ValueError(f"无法按data/columns结构转换DataFrame: {e}") from e
            # 通用字典转DataFrame（每行是一个键值对）
            else:
                try:
                    return pd.DataFrame([raw_data])  # 转为单行DataFrame
                except Exception as e:
                    raise ValueError(f"无法将字典数据转换为DataFrame: {e}") from e
        
        # 情况3：其他无法转换的格式
        else:
            raise TypeError(
                f"不支持的数据类型 {type(raw_data)} 转换为DataFrame，原始数据：{str(raw_data)[:500]}"
            )

    def _normalize_case_style(self, value: str, supported: set, field_name: str) -> str:
        normalized = value.lower()
        if normalized not in supported:
            supported_values = ", ".join(sorted(supported))
            raise ValueError(f"{field_name} must be one of: {supported_values}")
        return normalized

    def _transform_request_data(self, data: Any) -> Any:
        if self.request_case_style == "raw":
            return data
        if self.request_case_style in {"auto", "camel"}:
            return transform_keys(data, snake_to_camel)
        if self.request_case_style == "snake":
            return transform_keys(data, camel_to_snake)
        return data

    def _transform_response_data(self, data: Any) -> Any:
        if self.response_case_style == "raw":
            return data
        if self.response_case_style in {"auto", "snake"}:
            return transform_keys(data, camel_to_snake)
        if self.response_case_style == "camel":
            return transform_keys(data, snake_to_camel)
        return data

    def close(self):
        try:
            self.session.close()
        except Exception:
            pass

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        self.close()
