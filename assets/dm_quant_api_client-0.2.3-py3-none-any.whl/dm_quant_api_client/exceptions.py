class Sm4HttpClientError(Exception):
    """Base exception for sm4 http client."""


class HttpStatusError(Sm4HttpClientError):
    def __init__(self, status_code: int, text: str):
        super().__init__(f"HTTP status={status_code}, body={text[:500]}")
        self.status_code = status_code
        self.text = text


class ResponseDecodeError(Sm4HttpClientError):
    pass


class CryptoError(Sm4HttpClientError):
    pass
