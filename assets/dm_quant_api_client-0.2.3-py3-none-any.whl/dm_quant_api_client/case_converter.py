import re
from typing import Any, Callable


_CASE_STYLE_PATTERN = re.compile(r"^_+")


def snake_to_camel(key: str) -> str:
    if not key:
        return key

    prefix = _CASE_STYLE_PATTERN.match(key)
    leading_underscores = prefix.group(0) if prefix else ""
    body = key[len(leading_underscores):]

    if not body or ("_" not in body and "-" not in body):
        return key

    parts = [part for part in re.split(r"[_-]+", body) if part]
    if not parts:
        return key

    return leading_underscores + parts[0] + "".join(
        part[:1].upper() + part[1:] for part in parts[1:]
    )


def camel_to_snake(key: str) -> str:
    if not key:
        return key

    prefix = _CASE_STYLE_PATTERN.match(key)
    leading_underscores = prefix.group(0) if prefix else ""
    body = key[len(leading_underscores):]

    if not body:
        return key

    normalized = body.replace("-", "_")
    normalized = re.sub(r"(.)([A-Z][a-z]+)", r"\1_\2", normalized)
    normalized = re.sub(r"([a-z0-9])([A-Z])", r"\1_\2", normalized)

    return leading_underscores + normalized.lower()


def transform_keys(data: Any, key_transform: Callable[[str], str]) -> Any:
    if isinstance(data, dict):
        return {
            key_transform(key) if isinstance(key, str) else key: transform_keys(value, key_transform)
            for key, value in data.items()
        }

    if isinstance(data, list):
        return [transform_keys(item, key_transform) for item in data]

    if isinstance(data, tuple):
        return tuple(transform_keys(item, key_transform) for item in data)

    return data
